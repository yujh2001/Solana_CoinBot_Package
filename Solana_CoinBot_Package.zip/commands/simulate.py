
def simulate(update, context):
    update.message.reply_text("시뮬레이션 기능입니다. 토큰 주소를 입력해주세요.")
