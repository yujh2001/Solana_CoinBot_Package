
def report(update, context):
    update.message.reply_text("트렌딩 및 리포트를 전송합니다.")
