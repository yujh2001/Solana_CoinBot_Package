
def help_command(update, context):
    update.message.reply_text("""
사용 가능한 명령어:
/price <토큰주소> - 실시간 시세 조회
/simulate <토큰주소> - 전략 시뮬레이션
/track <지갑주소> - 고래 등록
/report - 리포트 제공
/gamble - 겜블 추천
/help - 명령어 설명
""")
