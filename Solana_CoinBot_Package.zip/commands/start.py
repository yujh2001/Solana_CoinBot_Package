
from telegram import ReplyKeyboardMarkup

def start(update, context):
    keyboard = [
        ["/price", "/simulate"],
        ["/track", "/report"],
        ["/gamble", "/help"]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    update.message.reply_text("Solana CoinBot에 오신 것을 환영합니다!", reply_markup=reply_markup)
