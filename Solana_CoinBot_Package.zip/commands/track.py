
def track(update, context):
    update.message.reply_text("지갑을 추적 리스트에 등록했습니다.")
