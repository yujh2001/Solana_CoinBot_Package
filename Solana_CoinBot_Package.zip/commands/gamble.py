
def gamble(update, context):
    update.message.reply_text("겜블 추천 토큰을 제공합니다.")
