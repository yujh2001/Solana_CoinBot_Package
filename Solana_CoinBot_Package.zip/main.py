
from telegram.ext import Application, CommandHandler
from commands import start, price, simulate, track, report, gamble, help_command

import os
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")

app = Application.builder().token(TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("price", price))
app.add_handler(CommandHandler("simulate", simulate))
app.add_handler(CommandHandler("track", track))
app.add_handler(CommandHandler("report", report))
app.add_handler(CommandHandler("gamble", gamble))
app.add_handler(CommandHandler("help", help_command))

app.run_polling()
